# Puppet module for OpenRefine

Installs OpenRefine, a data management tool from Google.

https://github.com/OpenRefine/OpenRefine

## Required Puppet Modules

* `boxen`

## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.
