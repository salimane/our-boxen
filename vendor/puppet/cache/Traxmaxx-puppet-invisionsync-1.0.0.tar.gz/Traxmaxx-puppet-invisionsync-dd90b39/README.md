# InVision Sync Puppet Module for Boxen

Install [InVision Sync](http://blog.invisionapp.com/invision-sync/) for Mac OS X.

## Usage

```puppet
include invisionsync
```

## Required Puppet Modules

* `boxen`

## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.
