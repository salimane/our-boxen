# Heroku Toolbelt Puppet Module for Boxen

Install [Heroku Toolbelt](https://toolbelt.heroku.com/), command-line tooling for working with the Heroku platform, on OS X.

## Usage

```puppet
includ heroku_toolbelt
```

## Required Puppet Modules

* `boxen`

## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.
