# Libreoffice Puppet Module for Boxen

## Usage

```puppet
include libreoffice
```

## Required Puppet Modules

* boxen

