[![Build Status](https://travis-ci.org/boxen/puppet-googledrive.png?branch=master)](https://travis-ci.org/boxen/puppet-googledrive)
# Google Drive Sync Puppet Module for Boxen

A Google Drive Sync module for Boxen.

## Usage

```puppet
include googledrive
```

## Required Puppet Modules

* `boxen`
