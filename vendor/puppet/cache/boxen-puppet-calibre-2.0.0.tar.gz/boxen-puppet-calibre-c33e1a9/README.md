# Calibre Puppet Module for Boxen

[![Build Status](https://travis-ci.org/boxen/puppet-calibre.png?branch=master)](https://travis-ci.org/boxen/puppet-calibre)

Install [Calibre](http://calibre-ebook.com/), an ebook manager for Mac

## Usage

```puppet
include calibre
```

## Required Puppet Modules

* `boxen`

## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.
