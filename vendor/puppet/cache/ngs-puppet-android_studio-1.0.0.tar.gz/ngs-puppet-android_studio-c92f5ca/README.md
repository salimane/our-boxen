# [Android Studio](http://developer.android.com/sdk/installing/studio.html) Puppet Module for Boxen

## Usage

```puppet
include android_studio
```

## Required Puppet Modules

None.

## Developing

Write code.

Run `script/cibuild`.
