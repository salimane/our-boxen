# Pixman Puppet Module for Boxen

Installs [Pixman](http://pixman.org/).

[![Build Status](https://travis-ci.org/mattheath/puppet-pixman.png?branch=master)](https://travis-ci.org/mattheath/puppet-pixman)

## Usage

```puppet
include pixman
```

## Required Puppet Modules

* `boxen`
* `homebrew`
