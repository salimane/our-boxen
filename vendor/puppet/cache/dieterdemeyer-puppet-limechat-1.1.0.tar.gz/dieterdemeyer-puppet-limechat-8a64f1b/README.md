# LimeChat Puppet Module for Boxen

Install [LimeChat](http://limechat.net/mac/), an IRC client for Mac OS X.

## Usage

```puppet
include limechat
```

## Required Puppet Modules

* `boxen`

## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.
