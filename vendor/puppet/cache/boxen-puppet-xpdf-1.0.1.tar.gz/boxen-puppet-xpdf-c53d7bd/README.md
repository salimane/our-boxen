# XPDF Puppet Module for Boxen

[![Build Status](https://travis-ci.org/boxen/puppet-xpdf.png?branch=master)](https://travis-ci.org/boxen/puppet-xpdf)

## Usage

```puppet
include xpdf
```

## Required Puppet Modules

* `boxen`
* `homebrew`
* `stdlib`
