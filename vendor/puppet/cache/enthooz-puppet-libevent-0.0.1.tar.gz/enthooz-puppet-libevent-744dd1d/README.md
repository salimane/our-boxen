# libevent Puppet Module for Boxen

## Usage

```puppet
include libevent
```

## Required Puppet Modules

* boxen
* homebrew


## Not sure if stdlib is required
* stdlib
