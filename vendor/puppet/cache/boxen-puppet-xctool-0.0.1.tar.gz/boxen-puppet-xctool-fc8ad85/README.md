# Puppet Module for xctool

Installs xctool, a replacement for Apple's xcodebuild that makes it easier to build and test iOS and Mac projects.

[![Build Status](https://travis-ci.org/boxen/puppet-xctool.png?branch=master)](https://travis-ci.org/boxen/puppet-xctool)

## Required Puppet Modules

* `boxen`

## Development

Write some code. Run `script/cibuild` to test it. Check the `script` directory for other useful tools.
