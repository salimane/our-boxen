require 'spec_helper'

describe 'sourcetree' do

  context 'with default version' do
    let(:params) { { } }

    version = '1.6.1'

    it { should contain_class('sourcetree') }
    it { should contain_package("SourceTree-#{version}").with_provider('appdmg') }
    it { should contain_package("SourceTree-1.6.1").with_source("http://downloads.atlassian.com/software/sourcetree/SourceTree_#{version}.dmg") }

  end

end
