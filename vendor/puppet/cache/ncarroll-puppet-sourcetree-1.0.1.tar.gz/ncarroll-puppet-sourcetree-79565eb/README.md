# SourceTree Puppet Module for Boxen

Installs SourceTree to /Applications.

[![Build Status](https://travis-ci.org/ncarroll/puppet-sourcetree.png?branch=master)](https://travis-ci.org/ncarroll/puppet-sourcetree)

## Usage

```
class { 'sourcetree':
  version => '1.6.1'
}
```

## Required Puppet Modules

* `boxen`

## Development

Write some code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.
